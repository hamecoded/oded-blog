# oded.me
admin password= odedblog
guest password= odedsagir ; email= odedsagir@gmail.com
site email= odedsme@gmail.com

# urls
all stacks are connected through github oauth

http://localhost:5173/
https://github.com/hamecoded/oded-blog
https://console.cloud.google.com/auth/clients?organizationId=0&project=oded-me
https://dcc.godaddy.com/control/portfolio/oded.me/settings?ventureId=610d4e99-bd08-423f-aa8c-747d622ef620&ua_placement=shared_header
https://supabase.com/dashboard/project/tbwskzgkmoztdejeiyhz
https://studio.youtube.com/channel/UCw3IaCO2FcF0ND20GgdmQZQ/videos/upload?filter=%5B%5D&sort=%7B%22columnType%22%3A%22date%22%2C%22sortOrder%22%3A%22DESCENDING%22%7D
youtube.com/@odedme


# Supabase
database password= pWNdbUe0xJbuKoVL

database password for odedme project= 0ZGwjd6fSwOSiaW9
project url= https://tbwskzgkmoztdejeiyhz.supabase.co
publishable key= sb_publishable_9X5gqFqONqoCSSMOXIOXfg_h74eDWVU
direct connection string= postgresql://postgres:[YOUR-PASSWORD]@db.tbwskzgkmoztdejeiyhz.supabase.co:5432/postgres
cli setup command= 
supabase login
supabase init
supabase link --project-ref tbwskzgkmoztdejeiyhz

  export SUPABASE_DB_URL='postgresql://postgres:0ZGwjd6fSwOSiaW9@db.tbwskzgkmoztdejeiyhz.supabase.co:5432/postgres'
  npm run deploy

# Google Cloud
OAuth client ID= 691512246509-0ufn69ki4k0iejfq9m82ul98o1lqu1le.apps.googleusercontent.com
name= oded-me

# resend.com
resend._domainkey= p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDjEi32AH+ozYoKV7GwtfCacGUepHjHmRrvuTX4h3jIOvgerAAhakWozRjGufqk+hCwlxv1CcgLrG3Dc5xZ8WfkgVUhBtbS7JilvHPc6FUHxLKCXdfAotXOyCQ/Oh7IwwaQ9mdKx92R2q0elu+MrM2vliSWl+DI1aMU/KKzB41zmwIDAQAB

api key= re_7DgGmk8M_DcoEwaQmv7Qo4XxsRCsHWs5D


